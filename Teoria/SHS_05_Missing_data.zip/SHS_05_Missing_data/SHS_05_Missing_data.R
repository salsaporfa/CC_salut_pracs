
### load boys data:
library(mice)
boys5 <- boys[boys$age >= 5, ]

par(las = 1, cex.main = 1, cex.axis = 1.2, cex.lab = 1.2, oma = c(0, 0, 0, 0), mar = c(4, 4, 1, 0))


plot(boys5$age,
     boys5$tv,
     xlab = "Age (decimal years)",
     ylab = "Testicular volume (ml)",
     pch = as.numeric(boys5$reg),
     col = as.numeric(boys5$reg))

regs <- levels(boys5$reg)
nreg <- length(regs)
legend("topleft",
       title = "Region",
       legend = levels(boys5$reg),
       pch = 1:nreg,
       col = 1:nreg,
       cex = 1.2,
       bty = "n")

library(mice)
### ?boys  # ("boys" data set is included in the "mice" package) 
### We will work only with boys 5-year old or older:
boys5 <- boys[boys$age >= 5, ]
head(boys5)

summary(boys5)

### percentage of complete cases:
100 * mean(complete.cases(boys5))

### percentage of missed cells:
100 * mean(is.na(boys5))

### percentage of missingness in each variable ():
varmiss <- 100 * colMeans(is.na(boys5))
varmiss <- data.frame(variable = names(varmiss),
                      miss100 = varmiss)
varmiss <- varmiss[varmiss$miss100 > 0, ]
varmiss <- varmiss[order(varmiss$miss100, decreasing = TRUE), ]
xtab <- xtable(varmiss)
names(xtab) <- c("{\\bf Variable}", "{\\bf Missed values (\\%)}")
print(xtab, size = 'small', sanitize.text.function = function(x) {x},
      include.rownames = FALSE, booktabs = TRUE)







mice::md.pattern(boys5, rotate.names = TRUE)

### ?mice
ini <- mice(boys5, maxit = 0)
ini ### note that age doesn't need to be imputed

### Get the imputation method and modify:
meth <- ini$method
### passive imputation for bmi:
meth["bmi"] <- "~I(wgt / (hgt / 100)^2)"

### Get the predictorMatrix and modify:
pred <- ini$predictorMatrix
### We made sure to exclude bmi as a predictor for the imputation of hgt and wgt:
pred[c("hgt", "wgt"), "bmi"] <- 0
pred

# meth["id"] <- ""  # do not impute "id"
# pred["id", ] <- 0 # we don't want "id" to be imputed
# pred[, "id"] <- 0 # we don't want "id" to be predictor

### number of imputed data sets:
M <- 10

### imputations:
imps <- mice(data = boys5,
             m = M,
             method = meth,
             predictorMatrix = pred,
             maxit = 20,
             printFlag = FALSE,  # set printFlag = TRUE until the analysis is definitive  
             seed = 666)

### mean in the original data set:
mean(boys5$tv, na.rm = TRUE)

### mean in the first imputed data set:
imp1 <- mice::complete(data = imps, action = 1)
mean(imp1$tv)

### pooled mean using all imputed data sets:
library(miceadds)  # withPool_MI
# list of means from each imputed data set:
means <- with(imps, mean(tv))
# pool means:
withPool_MI(means)

### variance in the original data set:
var(boys5$tv, na.rm = TRUE)

### variance in the first imputed data set:
imp1 <- mice::complete(data = imps, action = 1)
var(imp1$tv)

### pooled variance using all imputed data sets:
library(miceadds)  # withPool_MI
# list of variances from each imputed data set:
vars <- with(imps, var(tv))
# pool variances:
withPool_MI(vars)

modorig <- lm(tv ~ age + reg, data = boys5)
summary(modorig)

modimp1 <- lm(tv ~ age + reg, data = imp1)
summary(modimp1)

modimp <- with(imps, lm(tv ~ age + reg))
pooledest <- summary(pool(modimp), conf.int = TRUE)
pooledest

### age coefficient with original data set:
betaorig <- cbind(summary(modorig)$coefficients, confint(modorig))
betaorig <- betaorig["age", c("Estimate", "2.5 %", "97.5 %")]

### age coefficient with 1st imputed data set:
betaimp1 <- cbind(summary(modimp1)$coefficients, confint(modimp1))
betaimp1 <- betaimp1["age", c("Estimate", "2.5 %", "97.5 %")]

### age coefficient with all imputed data sets and pooling:
betaimps <- pooledest[which(pooledest$term == "age"), c("estimate", "2.5 %", "97.5 %")]

### bind results:
betas <- as.data.frame(rbind(betaorig, betaimp1, betaimps))
rownames(betas) <- c("Original data set", "1st imputed data set", "All imputed data sets (pooling)")

### plot:
par(las = 1,
    cex.main = 1,
    cex.axis = 1,
    cex.lab = 1.2,
    mgp = c(3, 0.45, 0),
    oma = c(0, 0, 0, 0),
    mar = c(4, 5, 1, 0))
nbetas <- dim(betas)[1]
yrange <- range(betas)
mycols <- c("red", "black", "forestgreen")
plot(x = c(1, nbetas), y = yrange,
     xlim = c(0.5, 3.5),
     type = "n",
     xlab = "",
     ylab = "",
     xaxt = "n")
mtext(text = expression(hat(beta)[age]),
      side = 2,
      line = 2.5,
      cex = 1.2)
mtext(text = "Data used in the main analysis",
      side = 1,
      line = 2.5,
      cex = 1.2)
axis(side = 1,
     at = 1:nbetas,
     labels = rownames(betas))
points(x = 1:nbetas, y = betas$estimate,
       pch = 19,
       col = mycols)
segments(x0 = 1:nbetas, y0 = betas$"2.5 %",
         x1 = 1:nbetas, y1 = betas$"97.5 %",
         lwd = 2, col = mycols)

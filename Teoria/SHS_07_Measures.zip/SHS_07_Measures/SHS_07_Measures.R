## ----example1binomtest, echo = FALSE----------------------------------------------------------------------------------------
pi0 <- 0.4
n <- 10
k <- 7
test1 <- binom.test(x = k, n = n, p = pi0, alternative = "two.sided")

## ----example1alpha, echo = FALSE--------------------------------------------------------------------------------------------
alpha <- 0.05


## ----example1binomtestbis, size="small"-------------------------------------------------------------------------------------
pi0 <- 0.4
n <- 10
k <- 7
test1 <- binom.test(x = k, n = n, p = pi0, alternative = "two.sided")
test1


## ----example1proptest, size="small"-----------------------------------------------------------------------------------------
test1asimp <- prop.test(x = k, n = n, p = pi0, alternative = "two.sided")
test1asimp









## ----exercise1a, echo=TRUE, eval=TRUE, size="footnotesize"------------------------------------------------------------------
### table of results:
tab <- as.data.frame(matrix(nrow = 3, ncol = 8))
names(tab) <- c("sample", "x", "n", "p", "exactCIlow", "exactCIupp", "approxCIlow", "approxCIupp")
tab$sample <- c("A", "B", "AB")
### add X, n and P:
xA <- 1
nA <- 19
xB <- 19
nB <- 186
tab$x <- c(xA, xB, NA)
tab$n <- c(nA, nB, NA)
aux <- tab[tab$sample != "AB", c("x", "n")]
tab[tab$sample == "AB", c("x", "n")] <- colSums(aux)
tab$p <- tab$x / tab$n
p <- tab$p
n <- tab$n
tab


## ----exercise1b, echo=TRUE, eval=TRUE, size="footnotesize"------------------------------------------------------------------
### asymptotic CI (using R as a calculator):
alpha <- 0.05
z <- qnorm(1 - alpha / 2)
error <- z * sqrt(p * (1 - p) / n)
pmatrix <- matrix(p, nrow = nrow(tab), ncol = 2)
errormatrix <- matrix(error, nrow = nrow(tab), ncol = 1, byrow = TRUE)
auxmatrix <- matrix(c(-1, 1), nrow = 1, ncol = 2, byrow = TRUE)
approxCI <- pmatrix + errormatrix %*% auxmatrix
tab[, c("approxCIlow", "approxCIupp")] <- approxCI
### asymptotic CI (with binom.approx):
tab$alpha <- alpha 
library(epitools) 
myapprox <- function(y) {
 binom.approx(x = as.numeric(y["x"]),  
              n = as.numeric(y["n"]),
              conf.level = 1 - as.numeric(y["alpha"]))
}
approxCI <- apply(tab, 1, FUN = myapprox)
CInames <- names(approxCI[[1]])
approxCI <- matrix(unlist(approxCI), nrow = nrow(tab), ncol = 6, byrow = TRUE)
approxCI <- as.data.frame(approxCI)
names(approxCI) <- CInames


## ----exercise1c, echo=TRUE, eval=TRUE, size="footnotesize"------------------------------------------------------------------
### exact CI (with binom.exact):
myexact <- function(y) binom.exact(x = as.numeric(y["x"]),
                                   n = as.numeric(y["n"]),
                                   conf.level = 1 - as.numeric(y["alpha"]))
exactCI <- apply(tab, 1, FUN = myexact)
CInames <- names(exactCI[[1]])
exactCI <- matrix(unlist(exactCI), nrow = nrow(tab), ncol = 6, byrow = TRUE)
exactCI <- as.data.frame(exactCI)
names(exactCI) <- CInames
tab[, c("exactCIlow", "exactCIupp")] <- exactCI[, c("lower", "upper")]
tab


## ----exercise1c2, echo=TRUE, eval=TRUE, size="small"------------------------------------------------------------------------
### LaTeX table:
mytab <- tab

loex <- sprintf("%.3f", mytab$exactCIlow)
upex <- sprintf("%.3f", mytab$exactCIupp)
mytab$ciex <- paste0("(", loex, ", ", upex, ")")

loap <- sprintf("%.3f", mytab$approxCIlow)
upap <- sprintf("%.3f", mytab$approxCIupp)
mytab$ciap <- paste0("(", loap, ", ", upap, ")")

mytab <- mytab[, c("sample", "x", "n", "p", "ciex", "ciap")]
mytab


## ----exercise1c3, echo=TRUE, eval=TRUE, results="asis"----------------------------------------------------------------------
### LaTeX table (cont.):
library(xtable)
mytab <- xtable(mytab, digits = c(0, 0, 0, 0, 3, 0, 0))
names(mytab) <- c("Sample", "$x$", "$n$", "$\\hat{P}$",
                  "CI\\textsubscript{95\\%} (exact)",
                  "CI\\textsubscript{95\\%} (approx)")
print(mytab,
      include.rownames = FALSE,
      booktabs = TRUE,
      sanitize.text.function = function(x) {x})


## ----exercise1d, echo=TRUE, eval=TRUE, size="footnotesize"------------------------------------------------------------------
### test for equal prevalences (approximate):
p0 <- 0.16
# Sample A:
id <- tab$sample == "A"
prop.test(x = tab$x[id], n = tab$n[id], p = p0, alternative = "two.sided", conf.level = 1 - alpha)


## ----exercise1e, echo=TRUE, eval=TRUE, size="footnotesize"------------------------------------------------------------------
# Sample B:
id <- tab$sample == "B"
prop.test(x = tab$x[id], n = tab$n[id], p = p0, alternative = "two.sided", conf.level = 1 - alpha)


## ----exercise1f, echo=TRUE, eval=TRUE, size="footnotesize"------------------------------------------------------------------
### test for equal prevalences (exact):
# Sample A:
id <- tab$sample == "A"
binom.test(x = tab$x[id], n = tab$n[id], p = p0, alternative = "two.sided", conf.level = 1 - alpha)


## ----exercise1g, echo=TRUE, eval=TRUE, size="footnotesize"------------------------------------------------------------------
# Sample B:
id <- tab$sample == "B"
binom.test(x = tab$x[id], n = tab$n[id], p = p0, alternative = "two.sided", conf.level = 1 - alpha)

